# 数据模型摘要

## Character
人物统一模型，玩家和NPC共用。包含身份、能力、性格、资源和记忆。

## Relationship
关系不是单一好感度，而是：好感、尊重、畏惧、信任、敌意、恩情，以及上下级/同僚/竞争/师徒等标签。

## Department / JobDefinition / PositionSlot
- Department：组织结构
- JobDefinition：职位模板、职责、权限、资格
- PositionSlot：世界中真实存在的一个编制席位，可空缺、占用、代理或暂停

## CareerRecord / EvaluationRecord / JobApplication
履历、考核和职位志愿分开保存，任命服务只读取这些事实，不让UI决定结果。

## RegionState / WorldIncident
为土地、城隍、水部、灾害等系统保留统一区域世界模型。

## TaskRecord / CaseRecord
任务和案件分离。世界事件也单独保存，避免所有内容都塞进“事件”一张表。

## ResidenceState / InventoryItem
为洞府和物品提供稳定归属模型，但当前不伪造玩法。
