import test from 'node:test';
import assert from 'node:assert/strict';
import { SeededRng } from '../dist/core/rng.js';
import { createInitialState } from '../dist/app/create-initial-state.js';
import { GameEngine } from '../dist/app/game-engine.js';
import { entityId } from '../dist/core/ids.js';

 test('随机种子可复现', () => {
  const a = new SeededRng(12345);
  const b = new SeededRng(12345);
  assert.deepEqual([a.next(), a.next(), a.next()], [b.next(), b.next(), b.next()]);
});

test('凡人面对基层小仙默认表现出明显敬畏', () => {
  const engine = new GameEngine(createInitialState());
  const reaction = engine.getEtiquette(entityId('char_mortal_li'), entityId('char_player'), 'mortal_world');
  assert.equal(reaction.posture, 'kneel');
  assert.equal(reaction.salutation, '仙长');
  assert.ok(reaction.awe >= 60);
});

test('时间推进按统一世界时钟执行', () => {
  const engine = new GameEngine(createInitialState());
  engine.time.resume(1);
  engine.time.advanceDays(31);
  const state = engine.snapshot();
  assert.equal(state.time.month, 2);
  assert.equal(state.time.day, 2);
});


test('高阶大神面对基层小仙可以表现出低关注度', () => {
  const engine = new GameEngine(createInitialState());
  const state = engine.snapshot();
  const base = state.characters[state.playerId];
  const high = {
    ...base,
    id: entityId('char_high_deity'),
    name: '高阶真君',
    identity: {
      ...base.identity,
      cultivationRankId: entityId('rank_supreme_true_person'),
      officeId: null,
    },
    resources: { ...base.resources, reputationHeaven: 90 },
  };
  const expanded = { ...state, characters: { ...state.characters, [high.id]: high } };
  const highEngine = new GameEngine(expanded);
  const reaction = highEngine.getEtiquette(high.id, expanded.playerId, 'heaven_court');
  assert.ok(reaction.attention < 50);
  assert.equal(reaction.posture, 'dismissive');
});
