import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../dist/app/create-initial-state.js';
import { GameEngine } from '../dist/app/game-engine.js';
import { entityId } from '../dist/core/ids.js';

function qualifiedState() {
  const state = createInitialState({ playerName: '测试玩家' });
  const player = state.characters[state.playerId];
  return {
    ...state,
    characters: {
      ...state.characters,
      [state.playerId]: {
        ...player,
        resources: { ...player.resources, merit: 120, reputationHeaven: 35 },
      },
    },
  };
}

test('玩家申请职位后不会直接获得职位', () => {
  const engine = new GameEngine(qualifiedState());
  engine.applyForPosition(engine.snapshot().playerId, entityId('pos_patrol_001'), 1);
  assert.equal(engine.snapshot().characters[engine.snapshot().playerId].identity.officeId, entityId('job_south_gate_guard'));
});

test('任命必须经过职位申请与任命流程，并生成履历', () => {
  const engine = new GameEngine(qualifiedState());
  const playerId = engine.snapshot().playerId;
  engine.applyForPosition(playerId, entityId('pos_patrol_001'), 1);
  const winner = engine.processAppointment(entityId('pos_patrol_001'));
  assert.equal(winner, playerId);
  assert.equal(engine.snapshot().characters[playerId].identity.officeId, entityId('job_patrol_envoy'));
  assert.ok(Object.values(engine.snapshot().careerRecords).some(x => x.characterId === playerId && x.jobId === entityId('job_patrol_envoy')));
});
