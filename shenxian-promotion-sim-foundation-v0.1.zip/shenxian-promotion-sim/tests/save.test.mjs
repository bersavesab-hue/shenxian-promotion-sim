import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../dist/app/create-initial-state.js';
import { MemorySaveRepository } from '../dist/storage/memory-save-repository.js';
import { MigrationRegistry } from '../dist/storage/migration-registry.js';
import { SaveManager } from '../dist/storage/save-manager.js';

 test('存档可以完整往返读取并经过状态校验', async () => {
  const repo = new MemorySaveRepository();
  const migrations = new MigrationRegistry();
  const manager = new SaveManager(repo, migrations, 1);
  const state = createInitialState({ seed: 77, playerName: '存档测试' });
  await manager.save('slot_1', state);
  const loaded = await manager.load('slot_1');
  assert.equal(loaded.playerId, state.playerId);
  assert.equal(loaded.meta.worldSeed, 77);
  assert.equal(loaded.characters[loaded.playerId].name, '存档测试');
});
