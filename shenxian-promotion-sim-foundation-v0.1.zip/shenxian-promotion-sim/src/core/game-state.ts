import type { EntityId } from './ids.js';
import type { FeatureFlags } from './feature-flags.js';
import type { Character } from '../domain/character.js';
import type { Relationship } from '../domain/relationship.js';
import type { Department, PositionSlot, CareerRecord, EvaluationRecord, JobApplication } from '../domain/career.js';
import type { RegionState, WorldIncident } from '../domain/world.js';
import type { TaskRecord, CaseRecord } from '../domain/gameplay.js';
import type { ResidenceState, InventoryItem } from '../domain/life.js';
import type { TimeRuntime, WorldTime } from '../domain/time.js';

export interface GameMetaState {
  readonly saveVersion: number;
  readonly worldSeed: number;
  readonly createdAtIso: string;
  readonly updatedAtIso: string;
  readonly revision: number;
}

export interface GameState {
  readonly meta: GameMetaState;
  readonly time: WorldTime;
  readonly timeRuntime: TimeRuntime;
  readonly playerId: EntityId;
  readonly features: FeatureFlags;
  readonly characters: Readonly<Record<string, Character>>;
  readonly relationships: Readonly<Record<string, Relationship>>;
  readonly departments: Readonly<Record<string, Department>>;
  readonly positions: Readonly<Record<string, PositionSlot>>;
  readonly careerRecords: Readonly<Record<string, CareerRecord>>;
  readonly evaluations: Readonly<Record<string, EvaluationRecord>>;
  readonly applications: Readonly<Record<string, JobApplication>>;
  readonly regions: Readonly<Record<string, RegionState>>;
  readonly incidents: Readonly<Record<string, WorldIncident>>;
  readonly tasks: Readonly<Record<string, TaskRecord>>;
  readonly cases: Readonly<Record<string, CaseRecord>>;
  readonly residences: Readonly<Record<string, ResidenceState>>;
  readonly inventory: Readonly<Record<string, InventoryItem>>;
}
