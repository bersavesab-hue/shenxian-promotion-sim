export type FeatureKey =
  | 'residence'
  | 'retainers'
  | 'master_apprentice'
  | 'family'
  | 'marriage'
  | 'artifacts'
  | 'alchemy'
  | 'refining'
  | 'immortal_market'
  | 'combat'
  | 'factions';

export type FeatureState = 'disabled' | 'registered' | 'active';
export type FeatureFlags = Readonly<Record<FeatureKey, FeatureState>>;

export const DEFAULT_FEATURE_FLAGS: FeatureFlags = {
  residence: 'registered',
  retainers: 'registered',
  master_apprentice: 'registered',
  family: 'registered',
  marriage: 'registered',
  artifacts: 'registered',
  alchemy: 'registered',
  refining: 'registered',
  immortal_market: 'registered',
  combat: 'registered',
  factions: 'registered',
};
