import { DomainError } from './errors.js';

export interface RandomSource {
  next(): number;
  int(minInclusive: number, maxInclusive: number): number;
  pick<T>(items: readonly T[]): T;
}

export class SeededRng implements RandomSource {
  private state: number;

  constructor(seed: number) {
    if (!Number.isInteger(seed)) {
      throw new DomainError('随机种子必须是整数', 'INVALID_RNG_SEED', { seed });
    }
    this.state = seed >>> 0;
  }

  next(): number {
    let x = this.state || 0x6d2b79f5;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.state = x >>> 0;
    return this.state / 0x100000000;
  }

  int(minInclusive: number, maxInclusive: number): number {
    if (!Number.isInteger(minInclusive) || !Number.isInteger(maxInclusive) || minInclusive > maxInclusive) {
      throw new DomainError('随机整数范围非法', 'INVALID_RNG_RANGE', { minInclusive, maxInclusive });
    }
    return minInclusive + Math.floor(this.next() * (maxInclusive - minInclusive + 1));
  }

  pick<T>(items: readonly T[]): T {
    if (items.length === 0) {
      throw new DomainError('不能从空集合随机选择', 'EMPTY_RNG_PICK');
    }
    return items[this.int(0, items.length - 1)]!;
  }
}
