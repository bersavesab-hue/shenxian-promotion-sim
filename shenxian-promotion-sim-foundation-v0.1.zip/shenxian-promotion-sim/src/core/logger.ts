export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  readonly level: LogLevel;
  readonly category: string;
  readonly message: string;
  readonly day: number;
  readonly context?: Readonly<Record<string, unknown>>;
}

export interface GameLogger {
  write(entry: LogEntry): void;
}

export class InMemoryLogger implements GameLogger {
  readonly entries: LogEntry[] = [];
  write(entry: LogEntry): void { this.entries.push(entry); }
}
