import type { GameState } from './game-state.js';
import { DomainError } from './errors.js';

export function validateGameState(state: GameState): void {
  if (!Number.isInteger(state.meta.saveVersion) || state.meta.saveVersion < 1) {
    throw new DomainError('存档版本非法', 'INVALID_SAVE_VERSION');
  }
  if (!state.characters[state.playerId]) {
    throw new DomainError('玩家实体不存在', 'MISSING_PLAYER_ENTITY', { playerId: state.playerId });
  }
  for (const position of Object.values(state.positions)) {
    if (position.occupantId && !state.characters[position.occupantId]) {
      throw new DomainError('职位指向不存在的人物', 'POSITION_OCCUPANT_MISSING', { positionId: position.id, occupantId: position.occupantId });
    }
    if (position.status === 'vacant' && position.occupantId !== null) {
      throw new DomainError('空缺职位不能存在任职者', 'VACANCY_HAS_OCCUPANT', { positionId: position.id });
    }
  }
  for (const relation of Object.values(state.relationships)) {
    if (!state.characters[relation.fromId] || !state.characters[relation.toId]) {
      throw new DomainError('关系指向不存在人物', 'RELATION_CHARACTER_MISSING', { relationshipId: relation.id });
    }
  }
}
