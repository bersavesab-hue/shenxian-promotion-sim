export interface DomainEvent<T = unknown> {
  readonly type: string;
  readonly occurredAtDay: number;
  readonly payload: T;
}

export type EventHandler<T = unknown> = (event: DomainEvent<T>) => void;

export class EventBus {
  private readonly handlers = new Map<string, Set<EventHandler>>();

  on<T>(type: string, handler: EventHandler<T>): () => void {
    const bucket = this.handlers.get(type) ?? new Set<EventHandler>();
    bucket.add(handler as EventHandler);
    this.handlers.set(type, bucket);
    return () => bucket.delete(handler as EventHandler);
  }

  emit<T>(event: DomainEvent<T>): void {
    for (const handler of this.handlers.get(event.type) ?? []) {
      handler(event);
    }
  }
}
