import { DomainError } from './errors.js';

export type EntityId = string & { readonly __brand: 'EntityId' };

const SAFE_ID = /^[a-z][a-z0-9_]{2,63}$/;

export function entityId(value: string): EntityId {
  if (!SAFE_ID.test(value)) {
    throw new DomainError(`非法实体ID: ${value}`, 'INVALID_ENTITY_ID', { value });
  }
  return value as EntityId;
}

export function makeEntityId(prefix: string, serial: number): EntityId {
  if (!SAFE_ID.test(prefix) || serial < 0 || !Number.isInteger(serial)) {
    throw new DomainError('无法生成实体ID', 'INVALID_ENTITY_ID_PARTS', { prefix, serial });
  }
  return entityId(`${prefix}_${String(serial).padStart(6, '0')}`);
}
