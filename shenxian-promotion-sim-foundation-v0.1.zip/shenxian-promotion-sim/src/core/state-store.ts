import type { GameState } from './game-state.js';
import { DomainError } from './errors.js';

export interface StateChange {
  readonly command: string;
  readonly beforeRevision: number;
  readonly afterRevision: number;
}

export type StateMutator = (draft: GameState) => GameState;

export class StateStore {
  private state: GameState;
  private locked = false;

  constructor(initialState: GameState) {
    this.state = structuredClone(initialState);
  }

  snapshot(): GameState {
    return structuredClone(this.state);
  }

  replace(next: GameState): void {
    if (this.locked) throw new DomainError('状态仓库事务进行中', 'STATE_STORE_LOCKED');
    this.state = structuredClone(next);
  }

  commit(command: string, mutator: StateMutator): StateChange {
    if (this.locked) throw new DomainError('禁止嵌套状态事务', 'NESTED_STATE_TRANSACTION', { command });
    this.locked = true;
    try {
      const before = this.state.meta.revision;
      const candidate = mutator(structuredClone(this.state));
      const next: GameState = {
        ...candidate,
        meta: {
          ...candidate.meta,
          updatedAtIso: new Date().toISOString(),
          revision: before + 1,
        },
      };
      this.state = structuredClone(next);
      return { command, beforeRevision: before, afterRevision: before + 1 };
    } finally {
      this.locked = false;
    }
  }
}
