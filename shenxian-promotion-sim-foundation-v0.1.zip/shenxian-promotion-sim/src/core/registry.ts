import { DomainError } from './errors.js';
import type { EntityId } from './ids.js';

export interface Identified { readonly id: EntityId }

export class Registry<T extends Identified> {
  private readonly items = new Map<EntityId, T>();

  register(item: T): void {
    if (this.items.has(item.id)) {
      throw new DomainError(`重复注册: ${item.id}`, 'DUPLICATE_REGISTRATION', { id: item.id });
    }
    this.items.set(item.id, item);
  }

  get(id: EntityId): T {
    const value = this.items.get(id);
    if (!value) {
      throw new DomainError(`未注册实体: ${id}`, 'MISSING_REGISTRY_ITEM', { id });
    }
    return value;
  }

  has(id: EntityId): boolean { return this.items.has(id); }
  values(): readonly T[] { return [...this.items.values()]; }
}
