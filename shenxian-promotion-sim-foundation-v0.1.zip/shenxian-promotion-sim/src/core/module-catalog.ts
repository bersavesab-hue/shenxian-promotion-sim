export type CoreModuleKey =
  | 'time'
  | 'state'
  | 'events'
  | 'save'
  | 'character'
  | 'relationship'
  | 'identity'
  | 'career'
  | 'world'
  | 'tasks'
  | 'cases'
  | 'life'
  | 'platform';

export interface ModuleDefinition {
  readonly key: CoreModuleKey;
  readonly dependsOn: readonly CoreModuleKey[];
  readonly owns: readonly string[];
}

export const MODULE_CATALOG: readonly ModuleDefinition[] = [
  { key: 'time', dependsOn: ['state', 'events'], owns: ['world clock', 'pause', 'speed'] },
  { key: 'state', dependsOn: [], owns: ['authoritative game state', 'transactions'] },
  { key: 'events', dependsOn: [], owns: ['domain event delivery'] },
  { key: 'save', dependsOn: ['state'], owns: ['serialization', 'migration', 'slot repository'] },
  { key: 'character', dependsOn: ['identity'], owns: ['character profile', 'abilities', 'personality', 'memory'] },
  { key: 'relationship', dependsOn: ['character'], owns: ['affinity', 'respect', 'fear', 'trust', 'hostility', 'debt'] },
  { key: 'identity', dependsOn: [], owns: ['species', 'cultivation rank', 'divine status', 'office identity'] },
  { key: 'career', dependsOn: ['character', 'identity', 'events'], owns: ['jobs', 'positions', 'applications', 'appointment', 'evaluation'] },
  { key: 'world', dependsOn: ['time', 'events'], owns: ['regions', 'world incidents'] },
  { key: 'tasks', dependsOn: ['world', 'character'], owns: ['task lifecycle'] },
  { key: 'cases', dependsOn: ['world', 'character'], owns: ['case lifecycle', 'evidence references'] },
  { key: 'life', dependsOn: ['character'], owns: ['residence', 'inventory extension points'] },
  { key: 'platform', dependsOn: [], owns: ['platform capabilities', 'lifecycle bridge'] },
];
