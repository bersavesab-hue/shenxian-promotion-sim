export interface PlatformLifecycle {
  onPause(handler: () => void): () => void;
  onResume(handler: () => void): () => void;
}

export interface PlatformCapabilities {
  readonly platform: 'android' | 'douyin' | 'wechat' | 'web_debug';
  readonly rewardedAds: boolean;
  readonly cloudSave: boolean;
  readonly haptics: boolean;
}

export interface PlatformAdapter {
  readonly capabilities: PlatformCapabilities;
  readonly lifecycle: PlatformLifecycle;
  nowIso(): string;
}
