import { entityId } from '../core/ids.js';
import type { CultivationRank, DivineStatus } from '../domain/identity.js';
import type { Department, JobDefinition } from '../domain/career.js';

export const CULTIVATION_RANKS: readonly CultivationRank[] = [
  { id: entityId('rank_mortal'), name: '凡人', order: 0, prestige: 0 },
  { id: entityId('rank_immortal'), name: '仙人', order: 1, prestige: 18 },
  { id: entityId('rank_flying_immortal'), name: '飞仙', order: 2, prestige: 28 },
  { id: entityId('rank_spirit_person'), name: '灵人', order: 3, prestige: 36 },
  { id: entityId('rank_true_person'), name: '真人', order: 4, prestige: 50 },
  { id: entityId('rank_spirit_immortal'), name: '灵仙', order: 5, prestige: 60 },
  { id: entityId('rank_flying_true_person'), name: '飞天真人', order: 6, prestige: 72 },
  { id: entityId('rank_supreme_true_person'), name: '太上真人', order: 7, prestige: 84 }
];

export const DIVINE_STATUSES: readonly DivineStatus[] = [
  { id: entityId('status_none'), name: '无正式神位', category: 'other', prestige: 0 },
  { id: entityId('status_celestial_register'), name: '天籍', category: 'celestial', prestige: 8 },
  { id: entityId('status_earth_deity'), name: '地祇', category: 'earth_deity', prestige: 16 },
  { id: entityId('status_thunder_official'), name: '雷部神职', category: 'thunder', prestige: 24 },
  { id: entityId('status_military_deity'), name: '护法神将', category: 'military', prestige: 28 }
];

export const DEPARTMENTS: readonly Department[] = [
  { id: entityId('dept_heaven_court'), name: '天庭', parentDepartmentId: null, domain: 'heaven' },
  { id: entityId('dept_south_gate'), name: '南天门值守司', parentDepartmentId: entityId('dept_heaven_court'), domain: 'heaven' },
  { id: entityId('dept_patrol'), name: '巡界司', parentDepartmentId: entityId('dept_heaven_court'), domain: 'heaven' },
  { id: entityId('dept_earth'), name: '地祇司', parentDepartmentId: entityId('dept_heaven_court'), domain: 'mortal' }
];

export const JOBS: readonly JobDefinition[] = [
  {
    id: entityId('job_south_gate_guard'),
    name: '南天门天兵',
    departmentId: entityId('dept_south_gate'),
    authority: 8,
    prestige: 10,
    duties: ['值守南天门', '核验往来身份', '处置一般异常'],
    permissions: ['inspect_visitor', 'detain_low_risk_target', 'report_incident'],
    qualification: { minMerit: 0, minReputationHeaven: 0, blockedByActivePunishment: false }
  },
  {
    id: entityId('job_patrol_envoy'),
    name: '巡界使',
    departmentId: entityId('dept_patrol'),
    authority: 18,
    prestige: 20,
    duties: ['巡查界域', '调查异常', '形成巡界报告'],
    permissions: ['inspect_region', 'investigate_incident', 'recommend_detention'],
    qualification: {
      minMerit: 80,
      minReputationHeaven: 15,
      minAbility: { investigation: 55 },
      requiredPreviousJobIds: [entityId('job_south_gate_guard')],
      blockedByActivePunishment: true
    }
  },
  {
    id: entityId('job_land_deity_assistant'),
    name: '土地属吏',
    departmentId: entityId('dept_earth'),
    authority: 14,
    prestige: 16,
    duties: ['协助辖区神务', '登记祈愿', '巡查香火与民情'],
    permissions: ['view_local_petitions', 'assist_local_governance'],
    qualification: {
      minMerit: 55,
      minReputationHeaven: 10,
      minAbility: { administration: 45 },
      blockedByActivePunishment: true
    }
  }
];
