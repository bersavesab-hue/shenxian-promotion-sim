import type { EntityId } from '../core/ids.js';

export interface ResidenceState {
  readonly id: EntityId;
  readonly ownerId: EntityId;
  readonly kind: 'dormitory' | 'shrine_residence' | 'official_residence' | 'immortal_mansion' | 'cave_abode';
  readonly level: number;
  readonly roomKeys: readonly string[];
  readonly retainerIds: readonly EntityId[];
}

export interface InventoryItem {
  readonly id: EntityId;
  readonly ownerId: EntityId;
  readonly templateId: EntityId;
  readonly quantity: number;
  readonly bound: boolean;
}
