import type { EntityId } from '../core/ids.js';

export interface Relationship {
  readonly id: EntityId;
  readonly fromId: EntityId;
  readonly toId: EntityId;
  readonly affinity: number;
  readonly respect: number;
  readonly fear: number;
  readonly trust: number;
  readonly hostility: number;
  readonly debt: number;
  readonly tags: readonly ('superior' | 'subordinate' | 'colleague' | 'rival' | 'mentor' | 'apprentice' | 'family' | 'partner' | 'retainer')[];
}
