export interface WorldTime {
  readonly absoluteDay: number;
  readonly year: number;
  readonly month: number;
  readonly day: number;
}

export type TimeSpeed = 0 | 1 | 2 | 5 | 10;

export interface TimeRuntime {
  readonly speed: TimeSpeed;
  readonly paused: boolean;
  readonly pauseReason: string | null;
}

export function worldTimeFromAbsoluteDay(absoluteDay: number): WorldTime {
  const safe = Math.max(0, Math.floor(absoluteDay));
  const year = Math.floor(safe / 360) + 1;
  const dayOfYear = safe % 360;
  const month = Math.floor(dayOfYear / 30) + 1;
  const day = (dayOfYear % 30) + 1;
  return { absoluteDay: safe, year, month, day };
}
