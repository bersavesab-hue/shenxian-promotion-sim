import type { EntityId } from '../core/ids.js';

export interface TaskRecord {
  readonly id: EntityId;
  readonly type: string;
  readonly assigneeId: EntityId;
  readonly issuerId: EntityId | null;
  readonly regionId: EntityId | null;
  readonly createdDay: number;
  readonly deadlineDay: number | null;
  readonly status: 'available' | 'active' | 'completed' | 'failed' | 'cancelled';
  readonly linkedIncidentId: EntityId | null;
}

export interface CaseRecord {
  readonly id: EntityId;
  readonly type: string;
  readonly regionId: EntityId | null;
  readonly stage: 'reported' | 'investigating' | 'hearing' | 'decided' | 'closed';
  readonly evidenceIds: readonly EntityId[];
  readonly participantIds: readonly EntityId[];
  readonly createdDay: number;
  readonly linkedIncidentId: EntityId | null;
}
