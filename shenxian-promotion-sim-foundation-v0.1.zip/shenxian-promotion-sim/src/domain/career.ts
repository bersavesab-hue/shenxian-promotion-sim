import type { EntityId } from '../core/ids.js';

export interface Department {
  readonly id: EntityId;
  readonly name: string;
  readonly parentDepartmentId: EntityId | null;
  readonly domain: 'heaven' | 'mortal' | 'underworld' | 'water' | 'thunder' | 'military' | 'mixed';
}

export interface QualificationRule {
  readonly minMerit: number;
  readonly minReputationHeaven: number;
  readonly minAbility?: Partial<Readonly<Record<'administration' | 'investigation' | 'combat' | 'strategy' | 'diplomacy' | 'cultivation', number>>>;
  readonly requiredPreviousJobIds?: readonly EntityId[];
  readonly allowedCultivationRankIds?: readonly EntityId[];
  readonly blockedByActivePunishment: boolean;
}

export interface JobDefinition {
  readonly id: EntityId;
  readonly name: string;
  readonly departmentId: EntityId;
  readonly authority: number;
  readonly prestige: number;
  readonly duties: readonly string[];
  readonly permissions: readonly string[];
  readonly qualification: QualificationRule;
}

export type PositionStatus = 'vacant' | 'occupied' | 'acting' | 'suspended';

export interface PositionSlot {
  readonly id: EntityId;
  readonly jobId: EntityId;
  readonly regionId: EntityId | null;
  readonly status: PositionStatus;
  readonly occupantId: EntityId | null;
  readonly openedDay: number;
}

export interface CareerRecord {
  readonly id: EntityId;
  readonly characterId: EntityId;
  readonly type: 'appointed' | 'promoted' | 'transferred' | 'demoted' | 'dismissed' | 'acting' | 'merit' | 'punishment';
  readonly jobId: EntityId | null;
  readonly day: number;
  readonly reason: string;
  readonly scoreImpact: number;
}

export interface EvaluationRecord {
  readonly id: EntityId;
  readonly characterId: EntityId;
  readonly periodStartDay: number;
  readonly periodEndDay: number;
  readonly performance: number;
  readonly superiorRating: number;
  readonly integrity: number;
  readonly result: 'poor' | 'qualified' | 'good' | 'excellent';
  readonly note: string;
}

export interface JobApplication {
  readonly id: EntityId;
  readonly positionId: EntityId;
  readonly characterId: EntityId;
  readonly preferenceRank: 1 | 2 | 3 | 4;
  readonly appliedDay: number;
  readonly status: 'submitted' | 'eligible' | 'ineligible' | 'selected' | 'rejected' | 'withdrawn';
}
