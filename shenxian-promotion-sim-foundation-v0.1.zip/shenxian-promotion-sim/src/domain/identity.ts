import type { EntityId } from '../core/ids.js';

export type Species = 'mortal' | 'cultivator' | 'immortal' | 'spirit' | 'demon' | 'ghost';

export interface CultivationRank {
  readonly id: EntityId;
  readonly name: string;
  readonly order: number;
  readonly prestige: number;
}

export interface DivineStatus {
  readonly id: EntityId;
  readonly name: string;
  readonly category: 'celestial' | 'earth_deity' | 'underworld' | 'water' | 'thunder' | 'military' | 'other';
  readonly prestige: number;
}

export interface IdentityProfile {
  readonly species: Species;
  readonly cultivationRankId: EntityId | null;
  readonly divineStatusId: EntityId | null;
  readonly officeId: EntityId | null;
}
