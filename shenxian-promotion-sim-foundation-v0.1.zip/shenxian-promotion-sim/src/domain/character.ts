import type { EntityId } from '../core/ids.js';
import type { IdentityProfile } from './identity.js';

export interface CharacterAbilities {
  readonly administration: number;
  readonly investigation: number;
  readonly combat: number;
  readonly strategy: number;
  readonly diplomacy: number;
  readonly cultivation: number;
}

export interface CharacterPersonality {
  readonly ambition: number;
  readonly caution: number;
  readonly loyalty: number;
  readonly empathy: number;
  readonly pride: number;
  readonly vindictiveness: number;
}

export interface CharacterResources {
  readonly merit: number;
  readonly incense: number;
  readonly spiritStones: number;
  readonly reputationHeaven: number;
  readonly reputationMortal: number;
  readonly reputationLocal: number;
}

export interface CharacterMemory {
  readonly id: EntityId;
  readonly subjectId: EntityId;
  readonly kind: 'helped' | 'harmed' | 'promoted' | 'humiliated' | 'saved' | 'betrayed' | 'promise' | 'other';
  readonly intensity: number;
  readonly createdDay: number;
  readonly note: string;
}

export interface Character {
  readonly id: EntityId;
  readonly name: string;
  readonly age: number;
  readonly origin: string;
  readonly identity: IdentityProfile;
  readonly abilities: CharacterAbilities;
  readonly personality: CharacterPersonality;
  readonly resources: CharacterResources;
  readonly memory: readonly CharacterMemory[];
  readonly active: boolean;
}
