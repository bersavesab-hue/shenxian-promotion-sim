import type { EntityId } from '../core/ids.js';

export interface RegionState {
  readonly id: EntityId;
  readonly name: string;
  readonly level: 'village' | 'town' | 'county' | 'prefecture' | 'province' | 'realm';
  readonly parentRegionId: EntityId | null;
  readonly population: number;
  readonly incense: number;
  readonly welfare: number;
  readonly disasterRisk: number;
  readonly demonThreat: number;
  readonly templeLevel: number;
}

export interface WorldIncident {
  readonly id: EntityId;
  readonly type: string;
  readonly regionId: EntityId | null;
  readonly startedDay: number;
  readonly expiresDay: number | null;
  readonly severity: number;
  readonly resolved: boolean;
  readonly tags: readonly string[];
}
