import { entityId } from '../core/ids.js';
import { DEFAULT_FEATURE_FLAGS } from '../core/feature-flags.js';
import type { GameState } from '../core/game-state.js';
import type { Character } from '../domain/character.js';
import type { Department, PositionSlot, CareerRecord } from '../domain/career.js';
import { worldTimeFromAbsoluteDay } from '../domain/time.js';
import { DEPARTMENTS } from '../content/starter-content.js';

function byId<T extends { readonly id: string }>(items: readonly T[]): Readonly<Record<string, T>> {
  return Object.fromEntries(items.map(x => [x.id, x])) as Readonly<Record<string, T>>;
}

function character(id: string, name: string, species: Character['identity']['species'], officeId: string | null, merit: number): Character {
  return {
    id: entityId(id),
    name,
    age: species === 'mortal' ? 34 : 96,
    origin: species === 'mortal' ? '东云州青溪县' : '天庭新录仙籍',
    identity: {
      species,
      cultivationRankId: species === 'mortal' ? entityId('rank_mortal') : entityId('rank_immortal'),
      divineStatusId: species === 'mortal' ? entityId('status_none') : entityId('status_celestial_register'),
      officeId: officeId ? entityId(officeId) : null,
    },
    abilities: { administration: 50, investigation: 58, combat: 56, strategy: 50, diplomacy: 48, cultivation: 45 },
    personality: { ambition: 60, caution: 55, loyalty: 55, empathy: 50, pride: 45, vindictiveness: 25 },
    resources: { merit, incense: 0, spiritStones: 50, reputationHeaven: 12, reputationMortal: 0, reputationLocal: 0 },
    memory: [],
    active: true,
  };
}

export interface NewGameOptions {
  readonly seed?: number;
  readonly playerName?: string;
}

export function createInitialState(options: NewGameOptions = {}): GameState {
  const seed = options.seed ?? 20260916;
  const player = character('char_player', options.playerName ?? '无名小仙', 'immortal', 'job_south_gate_guard', 35);
  const rival = character('char_zhang_xuanming', '张玄明', 'immortal', 'job_south_gate_guard', 52);
  const mortal = character('char_mortal_li', '李成福', 'mortal', null, 0);
  const characters = byId([player, rival, mortal]);

  const positions: readonly PositionSlot[] = [
    { id: entityId('pos_south_gate_001'), jobId: entityId('job_south_gate_guard'), regionId: null, status: 'occupied', occupantId: player.id, openedDay: 0 },
    { id: entityId('pos_south_gate_002'), jobId: entityId('job_south_gate_guard'), regionId: null, status: 'occupied', occupantId: rival.id, openedDay: 0 },
    { id: entityId('pos_patrol_001'), jobId: entityId('job_patrol_envoy'), regionId: null, status: 'vacant', occupantId: null, openedDay: 0 }
  ];

  const careerRecords: readonly CareerRecord[] = [
    { id: entityId('career_000001'), characterId: player.id, type: 'appointed', jobId: entityId('job_south_gate_guard'), day: 0, reason: '初始任命', scoreImpact: 0 },
    { id: entityId('career_000002'), characterId: rival.id, type: 'appointed', jobId: entityId('job_south_gate_guard'), day: 0, reason: '初始任命', scoreImpact: 0 }
  ];

  const now = new Date().toISOString();
  return {
    meta: { saveVersion: 1, worldSeed: seed, createdAtIso: now, updatedAtIso: now, revision: 0 },
    time: worldTimeFromAbsoluteDay(0),
    timeRuntime: { speed: 0, paused: true, pauseReason: 'new_game' },
    playerId: player.id,
    features: DEFAULT_FEATURE_FLAGS,
    characters,
    relationships: {},
    departments: byId(DEPARTMENTS as readonly Department[]),
    positions: byId(positions),
    careerRecords: byId(careerRecords),
    evaluations: {},
    applications: {},
    regions: {},
    incidents: {},
    tasks: {},
    cases: {},
    residences: {},
    inventory: {},
  };
}
