import { EventBus } from '../core/event-bus.js';
import { Registry } from '../core/registry.js';
import { SeededRng } from '../core/rng.js';
import { StateStore } from '../core/state-store.js';
import type { GameState } from '../core/game-state.js';
import { makeEntityId, type EntityId } from '../core/ids.js';
import type { CultivationRank, DivineStatus } from '../domain/identity.js';
import type { JobDefinition, JobApplication } from '../domain/career.js';
import { TimeProgressionService } from '../services/time-progression.service.js';
import { evaluateEtiquette, type EtiquetteContext } from '../services/etiquette.service.js';
import { decideAppointment } from '../services/appointment.service.js';
import { createCareerRecord } from '../services/career-history.service.js';
import { CULTIVATION_RANKS, DIVINE_STATUSES, JOBS } from '../content/starter-content.js';
import type { SaveManager } from '../storage/save-manager.js';

export class GameEngine {
  readonly events = new EventBus();
  readonly jobs = new Registry<JobDefinition>();
  readonly ranks = new Registry<CultivationRank>();
  readonly divineStatuses = new Registry<DivineStatus>();
  readonly store: StateStore;
  readonly time: TimeProgressionService;
  private readonly rng: SeededRng;

  constructor(initialState: GameState, private readonly saveManager?: SaveManager) {
    this.store = new StateStore(initialState);
    this.rng = new SeededRng(initialState.meta.worldSeed);
    this.time = new TimeProgressionService(this.store, this.events);
    for (const item of JOBS) this.jobs.register(item);
    for (const item of CULTIVATION_RANKS) this.ranks.register(item);
    for (const item of DIVINE_STATUSES) this.divineStatuses.register(item);
  }

  snapshot(): GameState { return this.store.snapshot(); }

  getEtiquette(observerId: EntityId, targetId: EntityId, scene: EtiquetteContext['scene']) {
    const state = this.store.snapshot();
    const observer = state.characters[observerId];
    const target = state.characters[targetId];
    if (!observer || !target) throw new Error('人物不存在');
    const observerJob = observer.identity.officeId ? this.jobs.get(observer.identity.officeId) : undefined;
    const targetJob = target.identity.officeId ? this.jobs.get(target.identity.officeId) : undefined;
    const observerRank = observer.identity.cultivationRankId ? this.ranks.get(observer.identity.cultivationRankId) : undefined;
    const targetRank = target.identity.cultivationRankId ? this.ranks.get(target.identity.cultivationRankId) : undefined;
    const observerDivineStatus = observer.identity.divineStatusId ? this.divineStatuses.get(observer.identity.divineStatusId) : undefined;
    const targetDivineStatus = target.identity.divineStatusId ? this.divineStatuses.get(target.identity.divineStatusId) : undefined;
    return evaluateEtiquette({ observer, target, observerJob, targetJob, observerRank, targetRank, observerDivineStatus, targetDivineStatus, scene });
  }

  applyForPosition(characterId: EntityId, positionId: EntityId, preferenceRank: 1 | 2 | 3 | 4): EntityId {
    const state = this.store.snapshot();
    const position = state.positions[positionId];
    if (!position || position.status !== 'vacant') throw new Error('职位不存在或当前无空缺');
    if (!state.characters[characterId]?.active) throw new Error('申请人不存在或无效');
    const serial = Object.keys(state.applications).length + 1;
    const id = makeEntityId('application', serial);
    const application: JobApplication = {
      id,
      positionId,
      characterId,
      preferenceRank,
      appliedDay: state.time.absoluteDay,
      status: 'submitted',
    };
    this.store.commit('career.apply_for_position', current => ({
      ...current,
      applications: { ...current.applications, [id]: application },
    }));
    return id;
  }

  processAppointment(positionId: EntityId): EntityId | null {
    const state = this.store.snapshot();
    const position = state.positions[positionId];
    if (!position || position.status !== 'vacant') throw new Error('职位不存在或无空缺');
    const job = this.jobs.get(position.jobId);
    const applications = Object.values(state.applications).filter(x => x.positionId === positionId);
    const careerHistory = Object.values(state.careerRecords);
    const evaluationByCharacter: Record<string, number> = {};
    for (const e of Object.values(state.evaluations)) {
      evaluationByCharacter[e.characterId] = Math.max(evaluationByCharacter[e.characterId] ?? 0, e.performance);
    }
    const decision = decideAppointment({
      position,
      job,
      applications,
      characters: state.characters,
      careerHistory,
      evaluationByCharacter,
      rng: this.rng,
    });
    const winnerId = decision.winnerId;
    if (!winnerId) return null;

    this.store.commit('career.appoint', current => {
      const oldCharacter = current.characters[winnerId];
      if (!oldCharacter) throw new Error('任命对象不存在');
      const recordSerial = Object.keys(current.careerRecords).length + 1;
      const record = createCareerRecord(recordSerial, winnerId, 'promoted', job.id, current.time.absoluteDay, decision.reason, 10);
      const updatedApplications = Object.fromEntries(Object.entries(current.applications).map(([key, app]) => [key, app.positionId === positionId ? { ...app, status: app.characterId === winnerId ? 'selected' : 'rejected' } : app])) as GameState['applications'];
      return {
        ...current,
        positions: {
          ...current.positions,
          [positionId]: { ...position, status: 'occupied', occupantId: winnerId },
        },
        characters: {
          ...current.characters,
          [winnerId]: { ...oldCharacter, identity: { ...oldCharacter.identity, officeId: job.id } },
        },
        applications: updatedApplications,
        careerRecords: { ...current.careerRecords, [record.id]: record },
      };
    });
    this.events.emit({ type: 'career.appointed', occurredAtDay: this.store.snapshot().time.absoluteDay, payload: { positionId, winnerId, jobId: job.id } });
    return winnerId;
  }

  async save(slotId: string): Promise<void> {
    if (!this.saveManager) throw new Error('未配置存档管理器');
    await this.saveManager.save(slotId, this.store.snapshot());
  }

  async load(slotId: string): Promise<void> {
    if (!this.saveManager) throw new Error('未配置存档管理器');
    this.store.replace(await this.saveManager.load(slotId));
  }
}
