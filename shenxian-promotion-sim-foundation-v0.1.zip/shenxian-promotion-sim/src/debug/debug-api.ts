import type { GameEngine } from '../app/game-engine.js';
import { entityId } from '../core/ids.js';

export class DebugApi {
  constructor(private readonly engine: GameEngine) {}
  advanceDays(days: number): void { this.engine.time.advanceDays(days); }
  snapshot() { return this.engine.snapshot(); }
  forceApplyPlayerToPatrol(): void {
    const state = this.engine.snapshot();
    this.engine.applyForPosition(state.playerId, entityId('pos_patrol_001'), 1);
  }
}
