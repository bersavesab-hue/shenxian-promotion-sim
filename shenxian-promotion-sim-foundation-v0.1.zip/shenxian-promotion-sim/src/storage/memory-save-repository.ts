import type { SaveRepository } from './save-repository.js';

export class MemorySaveRepository implements SaveRepository {
  private readonly slots = new Map<string, string>();
  async listSlots(): Promise<readonly string[]> { return [...this.slots.keys()].sort(); }
  async read(slotId: string): Promise<string | null> { return this.slots.get(slotId) ?? null; }
  async write(slotId: string, payload: string): Promise<void> { this.slots.set(slotId, payload); }
  async remove(slotId: string): Promise<void> { this.slots.delete(slotId); }
}
