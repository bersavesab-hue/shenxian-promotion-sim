export interface SaveRepository {
  listSlots(): Promise<readonly string[]>;
  read(slotId: string): Promise<string | null>;
  write(slotId: string, payload: string): Promise<void>;
  remove(slotId: string): Promise<void>;
}
