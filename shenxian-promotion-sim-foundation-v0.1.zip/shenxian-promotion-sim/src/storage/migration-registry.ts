import type { GameState } from '../core/game-state.js';
import { DomainError } from '../core/errors.js';

export type Migration = (state: GameState) => GameState;

export class MigrationRegistry {
  private readonly migrations = new Map<number, Migration>();

  register(fromVersion: number, migration: Migration): void {
    if (this.migrations.has(fromVersion)) throw new DomainError('重复存档迁移版本', 'DUPLICATE_MIGRATION', { fromVersion });
    this.migrations.set(fromVersion, migration);
  }

  migrate(state: GameState, targetVersion: number): GameState {
    let current = structuredClone(state);
    while (current.meta.saveVersion < targetVersion) {
      const migration = this.migrations.get(current.meta.saveVersion);
      if (!migration) {
        throw new DomainError('缺少存档迁移步骤', 'MISSING_MIGRATION', {
          fromVersion: current.meta.saveVersion,
          targetVersion,
        });
      }
      current = migration(current);
    }
    if (current.meta.saveVersion !== targetVersion) {
      throw new DomainError('存档版本高于当前程序', 'SAVE_VERSION_TOO_NEW', {
        saveVersion: current.meta.saveVersion,
        targetVersion,
      });
    }
    return current;
  }
}
