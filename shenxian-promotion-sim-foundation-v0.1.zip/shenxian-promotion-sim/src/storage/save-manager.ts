import type { GameState } from '../core/game-state.js';
import { DomainError } from '../core/errors.js';
import type { SaveRepository } from './save-repository.js';
import type { MigrationRegistry } from './migration-registry.js';
import { validateGameState } from '../core/state-validator.js';

export class SaveManager {
  constructor(
    private readonly repository: SaveRepository,
    private readonly migrations: MigrationRegistry,
    readonly currentVersion: number,
  ) {}

  async save(slotId: string, state: GameState): Promise<void> {
    validateGameState(state);
    const payload = JSON.stringify(state);
    await this.repository.write(slotId, payload);
  }

  async load(slotId: string): Promise<GameState> {
    const payload = await this.repository.read(slotId);
    if (!payload) throw new DomainError('存档不存在', 'SAVE_NOT_FOUND', { slotId });
    let parsed: unknown;
    try { parsed = JSON.parse(payload); }
    catch { throw new DomainError('存档JSON损坏', 'SAVE_JSON_CORRUPT', { slotId }); }
    const state = parsed as GameState;
    if (!state?.meta || typeof state.meta.saveVersion !== 'number') {
      throw new DomainError('存档结构非法', 'SAVE_SCHEMA_INVALID', { slotId });
    }
    const migrated = this.migrations.migrate(state, this.currentVersion);
    validateGameState(migrated);
    return migrated;
  }
}
