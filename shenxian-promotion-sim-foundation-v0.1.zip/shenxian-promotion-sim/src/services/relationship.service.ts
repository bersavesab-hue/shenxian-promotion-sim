import type { EntityId } from '../core/ids.js';
import type { Relationship } from '../domain/relationship.js';

const clamp = (value: number, min = -100, max = 100) => Math.max(min, Math.min(max, Math.round(value)));

export interface RelationshipDelta {
  readonly affinity?: number;
  readonly respect?: number;
  readonly fear?: number;
  readonly trust?: number;
  readonly hostility?: number;
  readonly debt?: number;
}

export function applyRelationshipDelta(current: Relationship, delta: RelationshipDelta): Relationship {
  return {
    ...current,
    affinity: clamp(current.affinity + (delta.affinity ?? 0)),
    respect: clamp(current.respect + (delta.respect ?? 0)),
    fear: clamp(current.fear + (delta.fear ?? 0), 0, 100),
    trust: clamp(current.trust + (delta.trust ?? 0)),
    hostility: clamp(current.hostility + (delta.hostility ?? 0), 0, 100),
    debt: clamp(current.debt + (delta.debt ?? 0)),
  };
}

export function relationshipId(fromId: EntityId, toId: EntityId): string {
  return `rel_${fromId}_${toId}`;
}
