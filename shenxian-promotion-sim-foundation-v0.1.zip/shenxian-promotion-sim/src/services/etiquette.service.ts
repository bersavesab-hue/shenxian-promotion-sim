import type { Character } from '../domain/character.js';
import type { JobDefinition } from '../domain/career.js';
import type { CultivationRank, DivineStatus } from '../domain/identity.js';
import type { Relationship } from '../domain/relationship.js';

export type EtiquettePosture = 'kneel' | 'deep_bow' | 'formal_salute' | 'casual_salute' | 'neutral' | 'dismissive';

export interface EtiquetteContext {
  readonly observer: Character;
  readonly target: Character;
  readonly observerJob?: JobDefinition | undefined;
  readonly targetJob?: JobDefinition | undefined;
  readonly observerRank?: CultivationRank | undefined;
  readonly targetRank?: CultivationRank | undefined;
  readonly observerDivineStatus?: DivineStatus | undefined;
  readonly targetDivineStatus?: DivineStatus | undefined;
  readonly relationship?: Relationship | undefined;
  readonly scene: 'mortal_world' | 'heaven_court' | 'official_office' | 'private';
}

export interface EtiquetteReaction {
  readonly posture: EtiquettePosture;
  readonly salutation: string;
  readonly awe: number;
  readonly attention: number;
  readonly refusalPressure: number;
}

const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));

function prestigeOf(character: Character, job?: JobDefinition, rank?: CultivationRank, divine?: DivineStatus): number {
  const speciesBase: Record<Character['identity']['species'], number> = {
    mortal: 0,
    cultivator: 12,
    immortal: 35,
    spirit: 18,
    demon: 18,
    ghost: 10,
  };
  return speciesBase[character.identity.species] + (job?.prestige ?? 0) + (rank?.prestige ?? 0) + (divine?.prestige ?? 0);
}

export function evaluateEtiquette(context: EtiquetteContext): EtiquetteReaction {
  const observerPrestige = prestigeOf(context.observer, context.observerJob, context.observerRank, context.observerDivineStatus);
  const targetPrestige = prestigeOf(context.target, context.targetJob, context.targetRank, context.targetDivineStatus);
  const gap = targetPrestige - observerPrestige;
  const relationRespect = context.relationship?.respect ?? 0;
  const relationFear = context.relationship?.fear ?? 0;
  const awe = clamp(35 + gap * 1.25 + relationRespect * 0.25 + relationFear * 0.35);
  const attention = clamp(55 + gap * 0.65 + Math.max(0, context.target.resources.reputationHeaven - 50) * 0.2);
  const refusalPressure = clamp(25 + gap * 0.8 + relationFear * 0.35);

  let posture: EtiquettePosture = 'neutral';
  if (gap >= 70 || (context.observer.identity.species === 'mortal' && context.target.identity.species === 'immortal')) posture = 'kneel';
  else if (gap >= 45) posture = 'deep_bow';
  else if (gap >= 20) posture = 'formal_salute';
  else if (gap >= 5) posture = 'casual_salute';
  else if (gap <= -45) posture = 'dismissive';

  let salutation = '阁下';
  const mortalFacingImmortal = context.target.identity.species === 'immortal' && context.observer.identity.species === 'mortal';
  if (context.targetJob && gap >= 20) salutation = '大人';
  if (mortalFacingImmortal) salutation = '仙长';
  if ((context.targetRank?.prestige ?? 0) >= 75) salutation = context.targetRank?.name ?? '上仙';

  return { posture, salutation, awe, attention, refusalPressure };
}
