import type { EntityId } from '../core/ids.js';
import { makeEntityId } from '../core/ids.js';
import type { CareerRecord } from '../domain/career.js';

export function createCareerRecord(
  serial: number,
  characterId: EntityId,
  type: CareerRecord['type'],
  jobId: EntityId | null,
  day: number,
  reason: string,
  scoreImpact: number,
): CareerRecord {
  return {
    id: makeEntityId('career', serial),
    characterId,
    type,
    jobId,
    day,
    reason,
    scoreImpact,
  };
}
