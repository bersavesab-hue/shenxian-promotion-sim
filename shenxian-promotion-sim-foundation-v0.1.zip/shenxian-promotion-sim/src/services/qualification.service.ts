import type { Character } from '../domain/character.js';
import type { JobDefinition } from '../domain/career.js';
import type { CareerRecord } from '../domain/career.js';

export interface QualificationResult {
  readonly eligible: boolean;
  readonly reasons: readonly string[];
}

export function evaluateQualification(
  character: Character,
  job: JobDefinition,
  careerHistory: readonly CareerRecord[],
): QualificationResult {
  const reasons: string[] = [];
  const rule = job.qualification;

  if (character.resources.merit < rule.minMerit) reasons.push(`功绩不足：${character.resources.merit}/${rule.minMerit}`);
  if (character.resources.reputationHeaven < rule.minReputationHeaven) reasons.push('天庭声望不足');

  if (rule.minAbility) {
    for (const [key, required] of Object.entries(rule.minAbility)) {
      if (required === undefined) continue;
      const actual = character.abilities[key as keyof Character['abilities']];
      if (actual < required) reasons.push(`${key}能力不足：${actual}/${required}`);
    }
  }

  if (rule.requiredPreviousJobIds?.length) {
    const held = new Set(careerHistory.filter(x => x.jobId !== null).map(x => x.jobId));
    if (!rule.requiredPreviousJobIds.some(id => held.has(id))) reasons.push('缺少必要任职经历');
  }

  if (rule.blockedByActivePunishment) {
    const recentPunishment = careerHistory.some(x => x.type === 'punishment' && x.scoreImpact < 0);
    if (recentPunishment) reasons.push('存在有效处分记录');
  }

  return { eligible: reasons.length === 0, reasons };
}
