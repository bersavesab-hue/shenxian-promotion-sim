import type { Character } from '../domain/character.js';
import type { EvaluationRecord } from '../domain/career.js';
import { makeEntityId } from '../core/ids.js';

const clamp = (value: number) => Math.max(0, Math.min(100, Math.round(value)));

export function createEvaluation(args: {
  readonly serial: number;
  readonly character: Character;
  readonly periodStartDay: number;
  readonly periodEndDay: number;
  readonly dutyPerformance: number;
  readonly superiorRating: number;
  readonly integrity: number;
  readonly note: string;
}): EvaluationRecord {
  const abilitySignal = (
    args.character.abilities.administration +
    args.character.abilities.investigation +
    args.character.abilities.diplomacy
  ) / 3;
  const performance = clamp(args.dutyPerformance * 0.6 + abilitySignal * 0.2 + args.character.resources.merit * 0.2);
  const superiorRating = clamp(args.superiorRating);
  const integrity = clamp(args.integrity);
  const total = performance * 0.5 + superiorRating * 0.3 + integrity * 0.2;
  const result: EvaluationRecord['result'] = total >= 85 ? 'excellent' : total >= 70 ? 'good' : total >= 55 ? 'qualified' : 'poor';
  return {
    id: makeEntityId('evaluation', args.serial),
    characterId: args.character.id,
    periodStartDay: args.periodStartDay,
    periodEndDay: args.periodEndDay,
    performance,
    superiorRating,
    integrity,
    result,
    note: args.note,
  };
}
