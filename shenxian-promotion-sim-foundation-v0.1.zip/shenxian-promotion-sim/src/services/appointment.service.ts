import type { RandomSource } from '../core/rng.js';
import type { Character } from '../domain/character.js';
import type { CareerRecord, JobApplication, JobDefinition, PositionSlot } from '../domain/career.js';
import type { EntityId } from '../core/ids.js';
import { evaluateQualification } from './qualification.service.js';

export interface CandidateScore {
  readonly characterId: EntityId;
  readonly eligible: boolean;
  readonly score: number;
  readonly reasons: readonly string[];
}

export interface AppointmentDecision {
  readonly positionId: EntityId;
  readonly winnerId: EntityId | null;
  readonly candidates: readonly CandidateScore[];
  readonly reason: string;
}

function evaluationBonus(characterId: EntityId, evaluationByCharacter: Readonly<Record<string, number>>): number {
  return evaluationByCharacter[characterId] ?? 0;
}

export function decideAppointment(args: {
  readonly position: PositionSlot;
  readonly job: JobDefinition;
  readonly applications: readonly JobApplication[];
  readonly characters: Readonly<Record<string, Character>>;
  readonly careerHistory: readonly CareerRecord[];
  readonly evaluationByCharacter: Readonly<Record<string, number>>;
  readonly rng: RandomSource;
}): AppointmentDecision {
  const candidates: CandidateScore[] = [];

  for (const application of args.applications.filter(x => x.positionId === args.position.id && x.status !== 'withdrawn')) {
    const character = args.characters[application.characterId];
    if (!character || !character.active) continue;
    const history = args.careerHistory.filter(x => x.characterId === character.id);
    const qualification = evaluateQualification(character, args.job, history);
    if (!qualification.eligible) {
      candidates.push({ characterId: character.id, eligible: false, score: 0, reasons: qualification.reasons });
      continue;
    }

    const abilityAverage = Object.values(character.abilities).reduce((a, b) => a + b, 0) / Object.values(character.abilities).length;
    const preferenceBonus = (5 - application.preferenceRank) * 2;
    const score =
      character.resources.merit * 0.35 +
      character.resources.reputationHeaven * 0.15 +
      abilityAverage * 0.25 +
      evaluationBonus(character.id, args.evaluationByCharacter) * 0.2 +
      preferenceBonus +
      args.rng.next() * 3;

    candidates.push({ characterId: character.id, eligible: true, score, reasons: [] });
  }

  const eligible = candidates.filter(x => x.eligible).sort((a, b) => b.score - a.score);
  const winner = eligible[0] ?? null;
  return {
    positionId: args.position.id,
    winnerId: winner?.characterId ?? null,
    candidates,
    reason: winner ? '按资格、履历、功绩、能力、考核与志愿综合任命' : '没有符合资格的候选人',
  };
}
