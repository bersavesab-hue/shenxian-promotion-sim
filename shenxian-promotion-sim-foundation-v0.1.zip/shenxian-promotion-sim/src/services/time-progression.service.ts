import type { StateStore } from '../core/state-store.js';
import type { EventBus } from '../core/event-bus.js';
import { worldTimeFromAbsoluteDay } from '../domain/time.js';
import type { TimeSpeed } from '../domain/time.js';

export interface DailySimulationSystem {
  readonly key: string;
  onDayAdvanced(absoluteDay: number): void;
}

export class TimeProgressionService {
  private readonly systems: DailySimulationSystem[] = [];

  constructor(
    private readonly store: StateStore,
    private readonly events: EventBus,
  ) {}

  registerSystem(system: DailySimulationSystem): void {
    if (this.systems.some(x => x.key === system.key)) throw new Error(`重复时间系统: ${system.key}`);
    this.systems.push(system);
  }

  setSpeed(speed: TimeSpeed): void {
    this.store.commit('time.set_speed', state => ({
      ...state,
      timeRuntime: { ...state.timeRuntime, speed },
    }));
  }

  pause(reason: string): void {
    this.store.commit('time.pause', state => ({
      ...state,
      timeRuntime: { ...state.timeRuntime, paused: true, pauseReason: reason, speed: 0 },
    }));
  }

  resume(speed: Exclude<TimeSpeed, 0> = 1): void {
    this.store.commit('time.resume', state => ({
      ...state,
      timeRuntime: { ...state.timeRuntime, paused: false, pauseReason: null, speed },
    }));
  }

  advanceDays(days: number): void {
    const count = Math.max(0, Math.floor(days));
    for (let i = 0; i < count; i += 1) {
      const before = this.store.snapshot().time;
      this.store.commit('time.advance_day', state => {
        const nextDay = state.time.absoluteDay + 1;
        return { ...state, time: worldTimeFromAbsoluteDay(nextDay) };
      });
      const after = this.store.snapshot().time;
      this.events.emit({ type: 'time.day_advanced', occurredAtDay: after.absoluteDay, payload: { before, after } });
      if (after.month !== before.month) this.events.emit({ type: 'time.month_changed', occurredAtDay: after.absoluteDay, payload: { before, after } });
      if (after.year !== before.year) this.events.emit({ type: 'time.year_changed', occurredAtDay: after.absoluteDay, payload: { before, after } });
      for (const system of this.systems) system.onDayAdvanced(after.absoluteDay);
      if (this.store.snapshot().timeRuntime.paused) break;
    }
  }
}
