import { readdir, readFile, stat } from 'node:fs/promises';
import { join, relative, basename } from 'node:path';

const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '');
const sourceRoot = join(root, 'src');
const forbiddenName = /(^|[_.-])(fix|patch|final|copy|old|backup|temp|tmp|new\d*|v\d+)($|[_.-])/i;
const forbiddenMarkers = /\b(TODO|FIXME|HACK)\b/;
const violations = [];

async function walk(dir) {
  for (const name of await readdir(dir)) {
    const path = join(dir, name);
    const info = await stat(path);
    if (info.isDirectory()) await walk(path);
    else {
      const rel = relative(root, path);
      if (forbiddenName.test(basename(path))) violations.push(`${rel}: 禁止临时/补丁式命名`);
      if (path.endsWith('.ts')) {
        const text = await readFile(path, 'utf8');
        if (!text.trim()) violations.push(`${rel}: 空源码文件`);
        if (forbiddenMarkers.test(text)) violations.push(`${rel}: 源码中存在 TODO/FIXME/HACK`);
      }
    }
  }
}

await walk(sourceRoot);
if (violations.length) {
  console.error(violations.join('\n'));
  process.exit(1);
}
console.log('结构审计通过：无临时补丁命名、空源码或 TODO/FIXME/HACK。');
