# Foundation Manifest V0.1

仓库：`shenxian-promotion-sim`

## 本次底层已实现

- Core：ID、错误、结果、随机、注册中心、事件总线、功能开关、日志、统一状态、事务仓库、状态校验、模块目录
- Domain：时间、人物、身份、关系、仕途、世界、任务、案件、洞府/物品
- Services：时间推进、关系变化、位格礼制、任职资格、考核生成、职位竞争任命、履历生成
- Storage：存档仓库接口、内存仓库、存档管理、版本迁移注册中心
- Platform：Android/抖音/微信/Web调试的平台能力边界
- App：新游戏状态工厂、正式GameEngine应用层
- Content：首批仙阶、神位、部门、职位注册数据，用于验证底层
- Debug：只经正式应用层操作的调试入口
- Quality：严格TypeScript、7项回归测试、结构审计、GitHub Actions验证

## 已验证硬规则

- UI未来只能调用GameEngine，不得直接写状态
- 申请职位不会直接获得职位
- 任命经过资格与竞争流程并生成履历
- 玩家与NPC共用核心人物结构
- 凡人/神仙位格反应不是写死对白
- 存档读取经过状态校验和迁移入口
- 禁止临时补丁式源码命名和TODO/FIXME/HACK残留
